/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.dao;

import com.cms.bll.EmployeeRegister;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author prash
 */
public class EmployeeRegisterDaoImpl implements EmployeeRegisterDao {

    @Override
    public void saveEmployeeRegister(EmployeeRegister e) throws IOException {

        try ( BufferedWriter bw = new BufferedWriter(new FileWriter("EmployeeRegister.txt", true))) {
            bw.write(e.getEmployeeID()+","+e.getFirstname() + "," + e.getLastname() + "," + e.getAddress() + "," + e.getEmail() + "," + e.getContact()+"," + e.getRole()+"," + e.getQualicication() + "," + e.getGender() + "," + e.getUsername() + "," + e.getPassword() + "," + e.getConfirmpassword()
            );
            bw.flush();
            bw.newLine();
            bw.close();
        }
    }

    @Override
    public void updateEmployeeRegister(EmployeeRegister e) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteEmployeeRegister(int eid) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void listEmployeeRegister(int eid) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<String> getAllEmployeeRegisters() throws IOException {
        ArrayList<String> fileData = new ArrayList<>();
        FileReader fr = new FileReader("EmployeeRegister.txt");
        BufferedReader br = new BufferedReader(fr);
        String line;
        while ((line = br.readLine()) != null) {
            fileData.add(line);
        }
        return fileData;
    }

}
