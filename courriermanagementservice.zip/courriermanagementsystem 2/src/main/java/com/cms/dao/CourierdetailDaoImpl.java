/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.dao;

import com.cms.bll.Courierdetail;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;

/**
 *
 * @author prash
 */
public class CourierdetailDaoImpl implements CourierdetailDao {

    @Override
    public void saveCourierdetail(Courierdetail c) throws IOException {

        try ( BufferedWriter bw = new BufferedWriter(new FileWriter("Courierdetail.txt", true))) {
            bw.write(c.getCid() + "," + c.getDate() + "," + c.getCustomername() + "," + c.getAddress() + "," + c.getContact() + "," + c.getSource() + "," + c.getDestination() + "," + c.getWeight() + "," + c.getCouriertype() + "," + c.getRate());
            bw.flush();
            bw.newLine();
            bw.close();
        }

    }

    @Override
    public void updateCourierdetail(Courierdetail c) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteCourierdetails(int cid) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void listCourierDetail(int cid) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<String> getAllCourierdetails() throws IOException {
        ArrayList<String> fileData = new ArrayList<>();
        FileReader fr = new FileReader("Courierdetail.txt");
        BufferedReader br = new BufferedReader(fr);
        String line;
        while ((line = br.readLine()) != null) {
            fileData.add(line);
        }
        return fileData;
    }

}
