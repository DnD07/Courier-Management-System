/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.dao;

import com.cms.bll.CustomerRegister;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author prash
 */
public interface CustomerRegisterDao {

    void saveCustomerRegister(CustomerRegister cu) throws IOException;

    void updateCustomerRegister(CustomerRegister cu) throws IOException;

    void deleteCustomerRegister(int cuid) throws IOException;

    void listCustomerRegister(int cuid) throws IOException;

    ArrayList<String> getAllCustomerRegisters() throws IOException;
}
