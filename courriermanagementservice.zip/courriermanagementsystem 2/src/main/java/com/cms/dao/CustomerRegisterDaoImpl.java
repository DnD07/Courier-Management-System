/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.dao;

import com.cms.bll.CustomerRegister;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author prash
 */
public class CustomerRegisterDaoImpl implements CustomerRegisterDao {

    @Override
    public void saveCustomerRegister(CustomerRegister cu) throws IOException {
        try ( BufferedWriter bw = new BufferedWriter(new FileWriter("CustomerRegister.txt", true))) {
            bw.write(cu.getCustomerID()+","+cu.getFirstname()+","+cu.getLastname()+","+cu.getAddress()+","+cu.getEmail()+","+cu.getContact()+","+cu.getGender()+","+cu.getUsername()+","+cu.getPassword()+","+cu.getConfirmpassword());
            bw.flush();
            bw.newLine();
            bw.close();
        
        }
    }

    @Override
    public void updateCustomerRegister(CustomerRegister cu) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteCustomerRegister(int cuid) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void listCustomerRegister(int cuid) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<String> getAllCustomerRegisters() throws IOException {
ArrayList<String> fileData = new ArrayList<>();
        FileReader fr = new FileReader("CustomerRegister.txt");
        BufferedReader br = new BufferedReader(fr);
        String line;
        while ((line = br.readLine()) != null) {
            fileData.add(line);
        }
        return fileData;
    }
    

    }

