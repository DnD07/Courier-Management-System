/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.dao;

import com.cms.bll.Courierdetail;
import java.util.ArrayList;
import java.io.IOException;

/**
 *
 * @author prash
 */
public interface CourierdetailDao {

    void saveCourierdetail(Courierdetail c) throws IOException;

    void updateCourierdetail(Courierdetail c) throws IOException;

    void deleteCourierdetails(int cid) throws IOException;

    void listCourierDetail(int cid) throws IOException;

    ArrayList<String> getAllCourierdetails() throws IOException;

}
