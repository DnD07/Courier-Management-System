/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.dao;

import com.cms.bll.EmployeeRegister;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author prash
 */
public interface EmployeeRegisterDao {

    void saveEmployeeRegister(EmployeeRegister e) throws IOException;

    void updateEmployeeRegister(EmployeeRegister e) throws IOException;

    void deleteEmployeeRegister(int eid) throws IOException;

    void listEmployeeRegister(int eid) throws IOException;

    ArrayList<String> getAllEmployeeRegisters() throws IOException;
}
