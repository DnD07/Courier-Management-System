/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.bll;

/**
 *
 * @author prash
 */
public class Courierdetail {

    private int cid;
    private int date;
    private String customername;
    private String address;
    private int contact;
    private String source;
    private String destination;
    private int weight;
    private String couriertype;
    private int rate;

    public Courierdetail(int cid, int date, String customername, String address, int contact, String source, String destination, int weight, String couriertype, int rate) {
        this.cid = cid;
        this.date = date;
        this.customername = customername;
        this.address = address;
        this.contact = contact;
        this.source = source;
        this.destination = destination;
        this.weight = weight;
        this.couriertype = couriertype;
        this.rate = rate;
    }

    public Courierdetail() {

    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public String getCustomername() {
        return customername;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getContact() {
        return contact;
    }

    public void setContact(int contact) {
        this.contact = contact;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getCouriertype() {
        return couriertype;
    }

    public void setCouriertype(String couriertype) {
        this.couriertype = couriertype;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

}
