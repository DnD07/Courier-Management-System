/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.courriermanagementsystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;



public class User {

   
    private String name;
    private String username;
    private String password;
    String filepath;
    public User(String name, String username, String password) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.filepath = filepath;
    }
    
    public String getName() {return name;}
    public void setName(String name) { this.name = name;}
    public String getUsername() {return username;}
    public void setUsername(String username) {this.username = username;}
    public String getPassword() {return password;}
    public void setPassword(String password) {this.password = password;}
    public String getFilepath(){return filepath;}
    public void setFilepath(String filepath){this.filepath=filepath;}
    
    public void login()
    {
      String line,word;
      String userName =null, pass=null;
      String username = getUsername();
      String passWord = getPassword();
      String afile = getFilepath();
      Scanner scan;
      StringTokenizer st = null;
      File file = new File(afile);
       try {
            scan = new Scanner(file);
            
            while(scan.hasNextLine() )
            {
                line = scan.nextLine();
                st = new StringTokenizer(line,",");
                int i=0;
                while(st.hasMoreTokens())
                {
                  word = st.nextToken();
                  if(i==1)
                  {
                     userName = word; 
                  }
                  if(i==2)
                  {
                      pass = word;
                  }
                    
                  i++; 
                }
                if( username.equals(userName) && (password.equals(pass)))
                {
                    ManagingStaffPanel emp = new ManagingStaffPanel();
                    emp.setVisible(true);
                    new ManagerLogin().setVisible(false);
                    return;  
                }
           }
            JOptionPane.showMessageDialog(null,"please enter correct information");
       
            scan.close();
               
        }
        catch (FileNotFoundException ex)
        {
        Logger.getLogger(ManagerLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
     
    }
}
